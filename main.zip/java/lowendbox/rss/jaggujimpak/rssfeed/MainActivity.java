package lowendbox.rss.jaggujimpak.rssfeed;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import lowendbox.rss.jaggujimpak.rssfeed.mDataObject.MyPost;
import lowendbox.rss.jaggujimpak.rssfeed.mFacebook.Login;
import lowendbox.rss.jaggujimpak.rssfeed.mFacebook.Myconfiguration;

import lowendbox.rss.jaggujimpak.rssfeed.R;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.share.widget.ShareDialog;
import com.squareup.picasso.Picasso;
import com.sromku.simple.fb.SimpleFacebook;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "err";
    private RecyclerView mRecyclerView;
    private EditText mEditText;
    private Button mFetchFeedButton;
    private SwipeRefreshLayout mSwipeLayout;
    private TextView mFeedTitleTextView;
    private TextView mFeedLinkTextView;
    private TextView mFeedDescriptionTextView;
    ImageView im;
    private List<RssFeedModel> mFeedModelList;
    private String mFeedTitle;
    private String mFeedLink;
    FloatingActionButton b;

    ImageView img;
    private String mimagelink;
    int i=0;
    SimpleFacebook fb;
    Bitmap bitmap;
    CallbackManager callbackManager;
    ShareDialog shareDialog;
    AccessTokenTracker accessTokenTracker;
    private String mFeedDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=(FloatingActionButton)findViewById(R.id.buttonfab);
        b.setVisibility(View.INVISIBLE);
        //t.setLogo(R.drawable.applogo);

        //Intent i1 = new Intent(this,MyService.class);
       //startService(i1);
        this.initilizefb();

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        //mEditText = (EditText) findViewById(R.id.rssFeedEditText);
       // mFetchFeedButton = (Button) findViewById(R.id.fetchFeedButton);
        mSwipeLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
     //  mFeedTitleTextView = (TextView) findViewById(R.id.feedTitle);
     //   mFeedDescriptionTextView = (TextView) findViewById(R.id.feedDescription);
      //  mFeedLinkTextView = (TextView) findViewById(R.id.feedLink);
        Log.d("sequence","oncreate"+i++);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

            check(MainActivity.this);
        mSwipeLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new FetchFeedTask().execute((Void) null);
            }
        });

        try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    "lowendbox.rss.jaggujimpak.rssfeed",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
            }
        } catch (PackageManager.NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }





    }
    public void check(Context c) {
        if (isConnectingToInternet(c)) {
            //Toast.makeText(getApplicationContext(), "internet is available", Toast.LENGTH_LONG).show();
            try {
                new FetchFeedTask().execute((Void) null);
            }catch (Exception e)
            {
                Log.d("Lost","lostconnection");
            }

            b.setVisibility(View.INVISIBLE);

        } else {
            Toast.makeText(this, "Check Internet Connection!", Toast.LENGTH_SHORT).show();
            b.setVisibility(View.VISIBLE);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    check(MainActivity.this);
                }
            });

        }
    }
    public class FetchFeedTask extends AsyncTask<Void, Void, Boolean> {

        private String urlLink;

        @Override
        protected void onPreExecute() {
            mSwipeLayout.setRefreshing(true);
            try {
                urlLink = "https://lowendbox.com/feed/";
                Log.d("sequence","onpreexexute"+i++);
            }catch (Exception e)
            {

            }

        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            if (TextUtils.isEmpty(urlLink))
                return false;

            try {
                if(!urlLink.startsWith("http://") && !urlLink.startsWith("https://"))
                    urlLink = "http://" + urlLink;
                Log.d("sequence","do in background"+i++);

                URL url = new URL(urlLink);
                InputStream inputStream = url.openConnection().getInputStream();
                mFeedModelList = parseFeed(inputStream);
                return true;
            } catch (IOException e) {
                Log.e(TAG, "Error", e);
            } catch (XmlPullParserException e) {
                Log.e(TAG, "Error", e);
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean success) {
            mSwipeLayout.setRefreshing(false);
            mRecyclerView.setAdapter(new RssFeedListAdapter(mFeedModelList));

            if (success) {
                //mFeedTitleTextView.setText("Feed Title: " + mFeedTitle);
                //mFeedDescriptionTextView.setText("Feed Description: " + mFeedDescription);
                //mFeedLinkTextView.setText("Feed Link: " + mFeedLink);
                Log.d("sequence","onpost"+i++);
                // Fill RecyclerView
                mRecyclerView.setAdapter(new RssFeedListAdapter(mFeedModelList));
            } else {

            }
        }
    }



    public List<RssFeedModel> parseFeed(InputStream inputStream) throws XmlPullParserException,
            IOException {
        String title = null;
        String link = null;
        String str=null;
        String description = null;
        String date=null;
        boolean isItem = false;
        List<RssFeedModel> items = new ArrayList<>();

        try {
            XmlPullParser xmlPullParser = Xml.newPullParser();
            xmlPullParser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            xmlPullParser.setInput(inputStream, null);
            Log.d("sequence","paresefeed"+i++);
            xmlPullParser.nextTag();
            while (xmlPullParser.next() != XmlPullParser.END_DOCUMENT) {
                int eventType = xmlPullParser.getEventType();

                String name = xmlPullParser.getName();
                if(name == null)
                    continue;

                if(eventType == XmlPullParser.END_TAG) {
                    if(name.equalsIgnoreCase("item")) {
                        isItem = false;
                    }
                    continue;
                }

                if (eventType == XmlPullParser.START_TAG) {
                    if(name.equalsIgnoreCase("item")) {
                        isItem = true;
                        continue;
                    }
                }

                Log.d("MyXmlParser", "Parsing name ==> " + name+"and"+xmlPullParser.getText());
                String result = "";
                if (xmlPullParser.next() == XmlPullParser.TEXT) {
                    result = xmlPullParser.getText();
                   // Toast.makeText(this, "result", Toast.LENGTH_SHORT).show();
                    xmlPullParser.nextTag();
                }

                if (name.equalsIgnoreCase("title")) {
                   // Toast.makeText(this,name+"title", Toast.LENGTH_SHORT).show();
                    title = result;

                    Log.d("Resultdatatitle", "Parsing name ==> " + name+"and"+result);
                } else if (name.equalsIgnoreCase("link")) {
                    //Toast.makeText(this,name+"          link", Toast.LENGTH_SHORT).show();
                    Log.d("Resultdatalink", "Parsing name ==> " + name+"and"+result);
                    link = result;
                } else if (name.equalsIgnoreCase("description")) {
                  //  Toast.makeText(this,name+"     description", Toast.LENGTH_SHORT).show();
                    Log.d("Resultdatadescript", "Parsing name ==> " + name+"and"+result);
                    String re="";
                    int c=1;
                   for(int i=0;i<result.length();i++)
                   {
                       Log.d("loop","elem"+result.charAt(i));
                       char a=result.charAt(i);
                       if(a=='&'|| c==0 )
                       {
                           Log.d("loopenter","elem"+a);

                           c=0;
                           re=re+result.charAt(i);
                           if(result.charAt(i)==';')
                           {
                               c=1;
                               Log.d("founddata1234","elem"+re);
                               if(result.contains(re))
                               {
                                   result=result.replace(re," ");
                               }
                               re="";

                           }

                       }


                   }
                    Log.d("loop","elem"+"done");
                    description = result;
                }
                else if (name.equalsIgnoreCase("pubDate")) {
                    //  Toast.makeText(this,name+"     description", Toast.LENGTH_SHORT).show();
                    Log.d("pubdate", "Parsing name ==> " + name+"and"+result);
                    date=result;

                }





                else if (name.equalsIgnoreCase("content:encoded")) {
                    //  Toast.makeText(this,name+"     description", Toast.LENGTH_SHORT).show();
                    Log.d("Resultdatacontent", "Parsing name ==> " + name+"and"+result);
                    try {
                         str = result.substring(result.indexOf("src"),result.indexOf(".jpg"));
                         str=str+".jpg??";
                       str = str.substring(str.indexOf("lowendbox"),str.indexOf("??"));
                        str="https://www."+str;
                        Log.d("getted", "Parsing name ==> " + name+"and"+str);

                    }
                    catch (Exception e)
                    {

                    }


                }

                if (title != null && link != null && description != null &&str!=null && date!=null) {
                    if(isItem) {
                        RssFeedModel item = new RssFeedModel(title, link, description,str,date);
                        items.add(item);
                    }
                    else {

                    }

                    title = null;
                    link = null;
                    description = null;
                    str=null;
                    date=null;
                    isItem = false;
                }
            }

            return items;
        } finally {
            inputStream.close();
        }
    }


    public class RssFeedModel {

        public String title;
        public String link;
        public String description;
        public String imageurl;
        public String date;

        public RssFeedModel(String title, String link, String description,String image,String da) {
            this.title = title;
            this.link = link;
            this.description = description;
            this.imageurl = image;
            this.date = da;
            Log.d("sequence","Rssfeedmodel"+i++);

        }
    }



    public class RssFeedListAdapter
            extends RecyclerView.Adapter<RssFeedListAdapter.FeedModelViewHolder> {

        private List<RssFeedModel> mRssFeedModels;

        public class FeedModelViewHolder extends RecyclerView.ViewHolder {
            private View rssFeedView;

            public FeedModelViewHolder(View v) {
                super(v);
                rssFeedView = v;
                Log.d("sequence","feedmodelviewholder"+i++);
            }
        }

        public RssFeedListAdapter(List<RssFeedModel> rssFeedModels) {
            mRssFeedModels = rssFeedModels;
        }

        @Override
        public FeedModelViewHolder onCreateViewHolder(ViewGroup parent, int type) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_rss_feed, parent, false);
            FeedModelViewHolder holder = new FeedModelViewHolder(v);
            Log.d("sequence","feedmodelviewholder"+i++);
            return holder;
        }

        @Override
        public void onBindViewHolder(FeedModelViewHolder holder, int position) {
            final RssFeedModel rssFeedModel = mRssFeedModels.get(position);
            ((TextView)holder.rssFeedView.findViewById(R.id.titleText)).setText(rssFeedModel.title);
            ((TextView)holder.rssFeedView.findViewById(R.id.descriptionText))
                    .setText(rssFeedModel.description);
            ((TextView)holder.rssFeedView.findViewById(R.id.textView4)).setText(rssFeedModel.date);
             img = (ImageView) holder.rssFeedView.findViewById(R.id.imageViewi);
            Picasso.with(MainActivity.this)
                    .load(rssFeedModel.imageurl)
                    .into(img);

            ((FloatingActionButton)holder.rssFeedView.findViewById(R.id.floatingActionButton4)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(rssFeedModel.link));
                    startActivity(i);

                }
            });
            ((FloatingActionButton)holder.rssFeedView.findViewById(R.id.floatingActionButton)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MyPost mypost = new MyPost();
                    mypost.setName(rssFeedModel.title);
                    mypost.setLink(rssFeedModel.link);
                    mypost.setDescription(rssFeedModel.description);
                    new Login(fb,MainActivity.this,mypost).login();

                }
            });
            ((FloatingActionButton)holder.rssFeedView.findViewById(R.id.floatingActionButton2)).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Uri uri = Uri.parse(rssFeedModel.imageurl);



                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_SEND);
                    intent.putExtra(Intent.EXTRA_TEXT,rssFeedModel.link);
                    intent.setType("text/plain");
                    intent.setPackage("com.whatsapp");
                    startActivity(intent);
                }
            });


            //((TextView)holder.rssFeedView.findViewById(R.id.linkText)).setText(rssFeedModel.link);
            Log.d("sequence","onBind"+i++);
        }

        @Override
        public int getItemCount() {
            return mRssFeedModels.size();
        }
    }
    public static boolean isConnectingToInternet(Context context)
    {
        ConnectivityManager connectivity =
                (ConnectivityManager) context.getSystemService(
                        Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        return true;
                    }
        }
        return false;
    }
    public void initilizefb()
    {
        SimpleFacebook.setConfiguration(new Myconfiguration().getMyConfigs());
        fb=SimpleFacebook.getInstance(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        fb=SimpleFacebook.getInstance(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        fb.onActivityResult(requestCode,resultCode,data);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.about: {
                Intent i = new Intent(this, showd.class);
                startActivity(i);
            }


            default:
                return super.onOptionsItemSelected(item);
        }
        //return super.onOptionsItemSelected(item);
    }
}
