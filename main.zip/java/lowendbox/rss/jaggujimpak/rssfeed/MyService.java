package lowendbox.rss.jaggujimpak.rssfeed;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by JAGGUJIMPAK on 28-01-2018.
 */

public class MyService extends Service {

    static int i=0;
    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(this, "Oncreate", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "Destroy"+i++, Toast.LENGTH_SHORT).show();
        Intent restartService = new Intent(this,MyService.class);
        sendBroadcast(restartService);

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this, "Service started"+i++, Toast.LENGTH_SHORT).show();

        Log.d("stopped","class");
        Intent restartService = new Intent(this,MyService.class);
        sendBroadcast(restartService);

        // If we get killed, after returning from here, restart
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
