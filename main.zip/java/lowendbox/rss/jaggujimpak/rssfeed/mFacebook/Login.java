package lowendbox.rss.jaggujimpak.rssfeed.mFacebook;

import android.content.Context;
import android.widget.Toast;

import lowendbox.rss.jaggujimpak.rssfeed.mDataObject.MyPost;

import com.sromku.simple.fb.Permission;
import com.sromku.simple.fb.SimpleFacebook;
import com.sromku.simple.fb.listeners.OnLoginListener;

import java.util.List;

/**
 * Created by JAGGUJIMPAK on 29-01-2018.
 */

public class Login {

    SimpleFacebook fb;
    Context c;
    MyPost myPost;

    public Login(SimpleFacebook fb, Context c,MyPost mypost) {
        this.fb = fb;
        this.c = c;
        this.myPost=mypost;

    }
    OnLoginListener loginListener = new OnLoginListener() {
        @Override
        public void onLogin(String accessToken, List<Permission> acceptedPermissions, List<Permission> declinedPermissions) {
           // Toast.makeText(c, "Login Success", Toast.LENGTH_SHORT).show();
            new PostPublisher(c,fb).publishfeed(myPost);
        }

        @Override
        public void onCancel() {
            Toast.makeText(c, "Cancelled", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onException(Throwable throwable) {

        }

        @Override
        public void onFail(String reason) {

        }
    };
    public void login()
    {
        fb.login(loginListener);
    }
}
