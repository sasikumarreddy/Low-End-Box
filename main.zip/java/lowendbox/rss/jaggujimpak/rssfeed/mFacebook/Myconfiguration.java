package lowendbox.rss.jaggujimpak.rssfeed.mFacebook;

import com.sromku.simple.fb.Permission;
import com.sromku.simple.fb.SimpleFacebook;
import com.sromku.simple.fb.SimpleFacebookConfiguration;

/**
 * Created by JAGGUJIMPAK on 29-01-2018.
 */

public class Myconfiguration {




    Permission[] permissions = new Permission[]{Permission.EMAIL,Permission.USER_PHOTOS,Permission.PUBLISH_ACTION};
    static final String App_ID="1838933879513724";
    public SimpleFacebookConfiguration getMyConfigs()
    {
        SimpleFacebookConfiguration configs=new SimpleFacebookConfiguration.Builder()
                .setAppId(App_ID)
                .setNamespace("Rssfeed")
                .setPermissions(permissions)
                .build();
        return configs;
    }
}
