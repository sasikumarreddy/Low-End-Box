package lowendbox.rss.jaggujimpak.rssfeed.mFacebook;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import lowendbox.rss.jaggujimpak.rssfeed.mDataObject.MyPost;

import com.sromku.simple.fb.SimpleFacebook;
import com.sromku.simple.fb.entities.Feed;
import com.sromku.simple.fb.listeners.OnPublishListener;

/**
 * Created by JAGGUJIMPAK on 29-01-2018.
 */

public class PostPublisher {


    Context c;
    SimpleFacebook fb;

    public PostPublisher(Context c, SimpleFacebook fb) {
        this.c = c;
        this.fb = fb;
    }
    OnPublishListener publishListener=new OnPublishListener() {
        @Override
        public void onComplete(String response) {
            super.onComplete(response);
            Toast.makeText(c,"Posted Successfully!", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onException(Throwable throwable) {
            super.onException(throwable);
            Toast.makeText(c, "Exception"+throwable, Toast.LENGTH_LONG).show();
            Log.d("error",""+throwable);

        }

        @Override
        public void onFail(String reason) {
            super.onFail(reason);

            Toast.makeText(c, "Onfail", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onThinking() {
            super.onThinking();
           // Toast.makeText(c, "Thinking", Toast.LENGTH_SHORT).show();
        }
    };

    public void publishfeed(MyPost mypost)
    {
        Feed feed=new Feed.Builder()
                .setMessage(mypost.getName())
                .setLink(mypost.getLink())
                .setDescription(mypost.getDescription())
                .build();

        fb.publish(feed,publishListener);
    }
}
