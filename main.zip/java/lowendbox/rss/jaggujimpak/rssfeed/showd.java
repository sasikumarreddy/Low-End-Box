package lowendbox.rss.jaggujimpak.rssfeed;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import lowendbox.rss.jaggujimpak.rssfeed.R;

public class showd extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showd);
    }
}
